// Export pages
export '/profile12/profile12_widget.dart' show Profile12Widget;
export '/homepage/homepage_widget.dart' show HomepageWidget;
export '/storepage/storepage_widget.dart' show StorepageWidget;
export '/scrollpage/scrollpage_widget.dart' show ScrollpageWidget;
export '/pages/login2/login2_widget.dart' show Login2Widget;
export '/pages/create_account2/create_account2_widget.dart'
    show CreateAccount2Widget;
export '/uploadpage/uploadpage_widget.dart' show UploadpageWidget;
export '/s_sdetailsstorepage/s_sdetailsstorepage_widget.dart'
    show SSdetailsstorepageWidget;
export '/scrollpage_a_d_s/scrollpage_a_d_s_widget.dart'
    show ScrollpageADSWidget;
